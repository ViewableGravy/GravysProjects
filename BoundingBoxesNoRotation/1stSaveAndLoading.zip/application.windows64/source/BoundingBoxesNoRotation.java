import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class BoundingBoxesNoRotation extends PApplet {

//CollideableEntity[] players;
ArrayList<CollideableEntity> players = new ArrayList<CollideableEntity>();
int CurrentEntity = 1;
ArrayList<Character> keys = new ArrayList<Character>();
boolean ctrl = false;

public void setup() {
  fill(255);
  strokeWeight(2);
  stroke(255);
  frameRate(60);
  
  Load("PlayerData.txt");
  /*
    players = new CollideableEntity[2];
   players[0] =  new CollideableEntity(new BoundingBox[]{new BoundingBox(100, 100, 100, 100)});
   players[1] = new CollideableEntity(new BoundingBox[]{new BoundingBox(350, 350, 100, 100)});
   */
}

public void draw() {
  background(0);

  //display
  for (CollideableEntity player : players) {
    player.Display();
  }

  //Add hitbox
  if (temp != null) {
    temp.UpdateParameters(mouseX, mouseY); 
    temp.Display();
  }

  //movement
  Move();

  textSize(20);
  stroke(0, 255, 0);
  text(CurrentEntity, 10, 30);
}

BoundingBox temp = null;
public void mouseClicked() {
  if (temp == null) {
    temp = new BoundingBox(mouseX, mouseY);
  } else {
    players.get(CurrentEntity-1).addBox(temp);
    temp = null;
  }
}

public void keyReleased() {
  println(key);
  keys.remove((Character)key);

  if (keyCode == CONTROL) {
    ctrl = false;
  }
}


public void keyPressed() {
  if (keyCode == CONTROL) {
    ctrl = true;
  }

  if (!keys.contains((Character)key)) {
    keys.add((Character)key);
  }

  if (keys.contains('u')) {
    if (CurrentEntity != players.size()) {
      CurrentEntity++;
    }
  } else if (keys.contains('i')) {
    if (CurrentEntity != 1) {
      CurrentEntity--;
    }
  }
}

public void Move() {

  //guarantee key's reset
  if (!keyPressed) {
    keys = new ArrayList<Character>();
  }
  if (keys.contains('s') && ctrl) {
    println("temp");
    Save();
  }

  if (keys.contains('w')) {
    players.get(0).translate(0, -1); 
    if (players.get(0).Collide(players.get(1))) {
      players.get(0).translate(0, 1);
      println(frameRate);
      stroke(100, 0, 0);
    } else {
      stroke(255);
    }
  } 
  if (keys.contains('s')) {
    players.get(0).translate(0, 1); 
    if (players.get(0).Collide(players.get(1))) {
      players.get(0).translate(0, -1);
      println(frameRate);
      stroke(100, 0, 0);
    } else {
      stroke(255);
    }
  }
  if (keys.contains('d')) {
    players.get(0).translate(1, 0); 
    if (players.get(0).Collide(players.get(1))) {
      players.get(0).translate(-1, 0);
      println(frameRate);
      stroke(100, 0, 0);
    } else {
      stroke(255);
    }
  } 
  if (keys.contains('a')) {
    players.get(0).translate(-1, 0); 
    if (players.get(0).Collide(players.get(1))) {
      players.get(0).translate(1, 0);
      println(frameRate);
      stroke(100, 0, 0);
    } else {
      stroke(255);
    }
  }
}

public boolean GRAVYEndArray(String line) {
  return (line.contains("]") & !line.contains(","));
}

//Given that this has literally no error handling and doesn't apply for any object other than this, It still works
public void Load(String filename) {
  ArrayList<CollideableEntity> tempArray = new ArrayList<CollideableEntity>();
  BufferedReader reader = createReader(filename);
  String line = null;
  try {
    do {
      ArrayList<BoundingBox> tempBoxes = new ArrayList<BoundingBox>(); 
      line = reader.readLine(); //Player: {
      line = reader.readLine(); //boxes: [
      while (!GRAVYEndArray(line)) {
        int x,y;
        int hei, wid;
        line = reader.readLine(); //box: {
        line = reader.readLine(); //Position {
        line = reader.readLine(); //x:
        x = (int)parseFloat(line.substring(line.lastIndexOf(":") + 1)); //error if NaN
        line = reader.readLine(); //y:
        y = (int)parseFloat(line.substring(line.lastIndexOf(":") + 1)); //error if NaN
        line = reader.readLine(); // },
        line = reader.readLine(); //Width:
        wid = (int)parseFloat(line.substring(line.lastIndexOf(":") + 1));
        line = reader.readLine(); //Height
        hei = (int)parseFloat(line.substring(line.lastIndexOf(":") + 1));
        tempBoxes.add(new BoundingBox(x, y, wid, hei));
        //println(x + "," + y + "," + hei + "," + wid);
        line = reader.readLine(); // },
        if (!line.contains("},")) break;
      }
      line = reader.readLine(); // "]"
      tempArray.add(new CollideableEntity(tempBoxes));
      line = reader.readLine();
    } while (!(line.contains("}") & !line.contains(",")));
    reader.close();
    players = tempArray;
  } 
  catch (IOException e) {
    e.printStackTrace();
  }
}

public void Save() {
  PrintWriter output = createWriter("PlayerData.txt");
  int i = 1;

  for (int j = 0; j < players.size(); j++) {
    output.println("Player: {");
    String indent = "  ";
    players.get(j).Save(output, indent);
    if (j == players.size() - 1) {
      output.println("}");
    } else {
      output.println("},");
    }
  }
  output.flush(); // Writes the remaining data to the file
  output.close(); // Finishes the file
}

public class BoundingBox {
  PVector pos;
  float wid,hei;
  boolean processing = false;
  
  public PVector GetPos() {
   return pos; 
  }
  
  public PVector GetWidHei() {
   return new PVector(wid,hei); 
  }
  
  BoundingBox(int x, int y, int wid, int hei) {
    this.pos = new PVector(x,y);
    this.wid = wid;
    this.hei = hei;
  }
  
  BoundingBox(int x, int y) {
    processing = true;
    this.pos = new PVector(x,y);
  }
  
  public void UpdateParameters(int x, int y) {
    if (processing) {
      this.wid = x - this.pos.x;
      this.hei = y - this.pos.y;
    }
  }
  
  public void Confirm() {
    
    if (wid < 0) {
     pos.x += wid;
     wid = abs(wid);
    }
    
    if (hei < 0) {
     pos.y += hei;
     hei = abs(hei);
    }
    
    processing = false;
  }
  
  public boolean Collide(BoundingBox other) {
   return  pos.x < other.pos.x + other.wid && 
           pos.x + wid > other.pos.x && 
           pos.y < other.pos.y + other.hei &&
           pos.y + hei > other.pos.y;
  }
  
  public void Display() {
   rect(pos.x,pos.y,wid,hei); 
  }
  
  public void translate(int x, int y) {
    this.pos.x += x;
    this.pos.y += y;
  }
  
  public void Save(PrintWriter output, String indentation) {
    output.println(indentation + "Position {");
    output.println(indentation + "  x: " + pos.x);
    output.println(indentation + "  y: " + pos.y);
    output.println(indentation + "},");
    output.println(indentation +"Width: " + wid);
    output.println(indentation +"Height: " + hei);
  }
}









class CollideableEntity {
  ArrayList<BoundingBox> boxes = new ArrayList<BoundingBox>();
  BoundingBox surroundingBox;

  CollideableEntity(BoundingBox[] boundingboxes) {
    for (BoundingBox box : boundingboxes) {
      boxes.add(box);
    }
    UpdateSurroundingBox();
  }

  CollideableEntity(ArrayList<BoundingBox> boundingboxes) {
    for (BoundingBox box : boundingboxes) {
      boxes.add(box);
    }
    UpdateSurroundingBox();
  }

  public void Save(PrintWriter output, String indent) {
    output.println(indent + "boxes: [");
    int i = 1;
    indent += "  ";
    for (int j = 0; j < boxes.size(); j++) {
      output.println(indent + "box: {");
      boxes.get(j).Save(output, indent + "  ");
      if (j == boxes.size() - 1) {
        output.println(indent + "}");
      } else {
        output.println(indent + "},");
      }
    }
    output.println(indent.substring(2) + "]");
  }

  private void UpdateSurroundingBox() {
    float minx = boxes.get(0).GetPos().x;
    float miny = boxes.get(0).GetPos().y;
    float maxx = boxes.get(0).GetPos().x;
    float maxy = boxes.get(0).GetPos().y;

    for (BoundingBox box : boxes) {
      PVector pos = box.GetPos();
      if (pos.x < minx) 
        minx = pos.x;
      if (pos.y < miny) 
        miny = pos.y; 
      PVector dim = box.GetWidHei();
      float right = pos.x + dim.x;
      if (right > maxx) {
        maxx = right;
      }
      float bottom = pos.y + dim.y;
      if (bottom > maxy) {
        maxy = bottom;
      }
    }
    surroundingBox = new BoundingBox(floor(minx), floor(miny), floor(maxx) - floor(minx), floor(maxy) - floor(miny));
  }

  public void addBox(BoundingBox box) {
    box.Confirm();
    boxes.add(box);
    UpdateSurroundingBox();
  }

  public boolean Collide(CollideableEntity other) {
    for (BoundingBox box : boxes) {
      for (BoundingBox otherbox : other.boxes) {
        if (box.Collide(otherbox)) {
          return true;
        }
      }
    }
    return false;
  }

  public void Display() {
    //surroundingBox.Display();
    for (BoundingBox box : boxes) {
      box.Display();
    }
  }

  public void translate(int x, int y) {
    for (BoundingBox box : boxes) {
      box.translate(x, y);
    }
    surroundingBox.translate(x, y);
  }
}
  public void settings() {  size(500, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "BoundingBoxesNoRotation" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
